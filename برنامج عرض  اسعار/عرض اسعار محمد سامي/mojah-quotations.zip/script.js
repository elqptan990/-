const $ = id => document.getElementById(id);
const STORAGE_KEY = "mojah_quotes_v1";
const PRODUCTS_STORAGE_KEY = "mojah_products_v1";
const DEFAULT_TERMS = "والاستلام علي ارض المصنع\nالأسعار سارية الي نهاية الشهر الحالي فقط";
const DEFAULT_PRODUCTS = [
  "MAFCO 160-Granule", "115/15", "MC-1", "MAFCO 180-Granule", "Polymer",
  "RC-2", "MAFCO 200-Granule", "Second quality", "MAFCO FIBER", "MAFCO 160",
  "MAFCO PROOF", "MAFCO 180", "MAFCO 200", "PRIMER D-41", "Emulsion"
];
let items = [];

function todayISO() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}
function money(value) {
  return (Number(value)||0).toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2});
}
function safeText(value) { return String(value ?? "").trim(); }
function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
}
function status(message, error=false) {
  $("status").textContent = message;
  $("status").style.color = error ? "#a62d27" : "#147044";
}
function newItem(data={}) {
  return {name:data.name||"", unit:data.unit||"رول", qty:data.qty ?? 1, price:data.price ?? 0};
}
function readProducts() {
  try {
    const saved = localStorage.getItem(PRODUCTS_STORAGE_KEY);
    if(saved === null) {
      localStorage.setItem(PRODUCTS_STORAGE_KEY,JSON.stringify(DEFAULT_PRODUCTS));
      return [...DEFAULT_PRODUCTS];
    }
    const products = JSON.parse(saved);
    if(!Array.isArray(products) || products.some(product => typeof product !== "string")) {
      throw new Error("invalid product catalog");
    }
    return products;
  } catch(e) {
    status("تعذر قراءة قائمة المنتجات المحفوظة.",true);
    return [];
  }
}
function writeProducts(products) {
  try {
    localStorage.setItem(PRODUCTS_STORAGE_KEY,JSON.stringify(products));
    return true;
  } catch(e) {
    status("تعذر حفظ قائمة المنتجات في المتصفح.",true);
    return false;
  }
}
function refreshProductCatalog() {
  const catalog = $("productCatalog");
  catalog.replaceChildren();
  readProducts().forEach(product => {
    const option = document.createElement("option");
    option.value = product;
    catalog.appendChild(option);
  });
}
function refreshProductManager() {
  const list = $("productManagementList");
  list.replaceChildren();
  readProducts().forEach((product,index) => {
    const row = document.createElement("div");
    row.className = "product-management-row";
    const input = document.createElement("input");
    input.type = "text";
    input.value = product;
    input.setAttribute("aria-label",`اسم المنتج ${index+1}`);
    const saveButton = document.createElement("button");
    saveButton.type = "button";
    saveButton.className = "btn small light";
    saveButton.textContent = "حفظ التعديل";
    saveButton.addEventListener("click",() => renameProduct(index,input.value));
    row.append(input,saveButton);
    list.appendChild(row);
  });
}
function saveProduct(name) {
  const product = safeText(name);
  if(!product) return false;
  const products = readProducts();
  if(products.some(saved => saved.toLocaleLowerCase() === product.toLocaleLowerCase())) return true;
  products.push(product);
  if(!writeProducts(products)) return false;
  refreshProductCatalog();
  status("تم حفظ المنتج في قائمة المنتجات على هذا الجهاز.");
  return true;
}
function renameProduct(index,name) {
  const product = safeText(name);
  if(!product) return status("اسم المنتج لا يمكن أن يكون فارغًا.",true);
  const products = readProducts();
  if(products.some((saved,i) => i !== index && saved.toLocaleLowerCase() === product.toLocaleLowerCase())) {
    return status("اسم المنتج موجود بالفعل في القائمة.",true);
  }
  products[index] = product;
  if(!writeProducts(products)) return;
  refreshProductCatalog();
  refreshProductManager();
  status("تم تعديل اسم المنتج وحفظه.");
}
function renderInputs() {
  const body = $("itemsBody");
  body.innerHTML = "";
  items.forEach((item,index) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td><input class="item-name" list="productCatalog" data-index="${index}" data-key="name" value="${esc(item.name)}" placeholder="اختر أو اكتب اسم المنتج"></td>
      <td><input data-index="${index}" data-key="unit" value="${esc(item.unit)}" placeholder="رول"></td>
      <td><input data-index="${index}" data-key="qty" type="number" min="0" step="any" value="${esc(item.qty)}"></td>
      <td><input data-index="${index}" data-key="price" type="number" min="0" step="0.01" value="${esc(item.price)}"></td>
      <td class="line-total">${money(Number(item.qty)*Number(item.price))}</td>
      <td><button type="button" class="remove" data-remove="${index}" title="حذف الصنف">×</button></td>`;
    body.appendChild(tr);
  });
  body.querySelectorAll("input").forEach(input => input.addEventListener("input", e => {
    const i = Number(e.target.dataset.index), key = e.target.dataset.key;
    items[i][key] = (key === "qty" || key === "price") ? Number(e.target.value) || 0 : e.target.value;
    renderPreview();
    const row = e.target.closest("tr");
    row.querySelector(".line-total").textContent = money(Number(items[i].qty)*Number(items[i].price));
  }));
  body.querySelectorAll(".item-name").forEach(input => input.addEventListener("change", e => {
    saveProduct(e.target.value);
  }));
  body.querySelectorAll("[data-remove]").forEach(btn => btn.addEventListener("click", () => {
    if(items.length === 1) items = [newItem()];
    else items.splice(Number(btn.dataset.remove),1);
    renderInputs(); renderPreview();
  }));
  refreshProductCatalog();
  renderPreview();
}
function numToArabicWordsSimple(n) {
  if (!Number.isFinite(n)) return "—";
  return money(n) + " ريال سعودي";
}
function renderPreview() {
  $("pQuoteNo").textContent = safeText($("quoteNo").value) || "—";
  $("pQuoteDate").textContent = $("quoteDate").value || "—";
  $("pCustomer").textContent = safeText($("customer").value) || "—";
  $("pSubject").textContent = safeText($("subject").value) || "عرض أسعار";
  $("pTerms").textContent = safeText($("terms").value);
  const body = $("pItemsBody");
  body.innerHTML = "";
  let subtotal = 0;
  items.forEach((item,i) => {
    const total = Math.max(0,Number(item.qty)||0)*Math.max(0,Number(item.price)||0);
    subtotal += total;
    const tr = document.createElement("tr");
    tr.innerHTML = `<td>${i+1}</td><td style="text-align:right">${esc(item.name)||"—"}</td><td>${esc(item.unit)||"—"}</td><td>${money(item.qty)}</td><td>${money(item.price)}</td><td>${money(total)}</td>`;
    body.appendChild(tr);
  });
  const discount = Math.min(subtotal,Math.max(0,Number($("discount").value)||0));
  const taxable = Math.max(0,subtotal-discount);
  const vat = $("vatEnabled").checked ? taxable*0.15 : 0;
  const grand = taxable+vat;
  $("pSubtotal").textContent = money(subtotal);
  $("pDiscount").textContent = money(discount);
  $("pTaxable").textContent = money(taxable);
  $("pVat").textContent = money(vat);
  $("pGrand").textContent = money(grand)+" ر.س";
  $("pWords").textContent = numToArabicWordsSimple(grand);
}
function formData() {
  return {
    id: $("quoteNo").value || `QT-${Date.now()}`,
    quoteNo:$("quoteNo").value, quoteDate:$("quoteDate").value,
    customer:$("customer").value, subject:$("subject").value,
    discount:$("discount").value, vatEnabled:$("vatEnabled").checked,
    terms:$("terms").value, items:items.map(x=>({...x})),
    updatedAt:new Date().toISOString()
  };
}
function setForm(data={}) {
  $("quoteNo").value = data.quoteNo || "";
  $("quoteDate").value = data.quoteDate || todayISO();
  $("customer").value = data.customer || "";
  $("subject").value = data.subject || "";
  $("discount").value = data.discount ?? 0;
  $("vatEnabled").checked = data.vatEnabled !== false;
  $("terms").value = data.terms ?? DEFAULT_TERMS;
  items = Array.isArray(data.items) && data.items.length ? data.items.map(newItem) : [newItem()];
  renderInputs(); renderPreview();
}
function readQuotes() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); }
  catch(e) { return []; }
}
function writeQuotes(quotes) {
  try { localStorage.setItem(STORAGE_KEY,JSON.stringify(quotes)); return true; }
  catch(e) { status("تعذر الحفظ في المتصفح. صدّر نسخة احتياطية قبل إغلاق الصفحة.",true); return false; }
}
function refreshSaved(selected="") {
  const select = $("savedQuotes"), quotes = readQuotes();
  select.innerHTML = '<option value="">اختر عرضًا محفوظًا</option>';
  quotes.sort((a,b)=>(b.updatedAt||"").localeCompare(a.updatedAt||"")).forEach(q=>{
    const option = document.createElement("option");
    option.value = q.id;
    option.textContent = `${q.quoteNo||"بدون رقم"} — ${q.customer||"بدون اسم"} — ${q.quoteDate||""}`;
    select.appendChild(option);
  });
  if(selected) select.value = selected;
}
function saveQuote() {
  const data = formData();
  if(!data.quoteNo) {
    data.quoteNo = `QT-${todayISO().replaceAll("-","")}-${String(Date.now()).slice(-4)}`;
    $("quoteNo").value = data.quoteNo;
  }
  data.id = data.quoteNo;
  const quotes = readQuotes();
  const idx = quotes.findIndex(q=>q.id===data.id);
  if(idx>=0) quotes[idx]=data; else quotes.push(data);
  if(writeQuotes(quotes)) { refreshSaved(data.id); status("تم حفظ عرض السعر على هذا الجهاز."); }
}
function downloadJSON(data, filename) {
  const blob = new Blob([JSON.stringify(data,null,2)],{type:"application/json;charset=utf-8"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a"); a.href=url; a.download=filename; a.click();
  URL.revokeObjectURL(url);
}
$("addItemBtn").addEventListener("click",()=>{items.push(newItem());renderInputs();});
$("addProductBtn").addEventListener("click",()=>{
  refreshProductManager();
  $("productDialog").showModal();
});
$("closeProductDialogBtn").addEventListener("click",()=>$("productDialog").close());
$("addProductForm").addEventListener("submit",e=>{
  e.preventDefault();
  const input=$("newProductName");
  const product=safeText(input.value);
  if(!product) return status("اكتب اسم المنتج أولًا.",true);
  if(saveProduct(product)) {
    input.value="";
    refreshProductManager();
    status("تم حفظ المنتج في قائمة المنتجات على هذا الجهاز.");
  }
});
$("printBtn").addEventListener("click",()=>{renderPreview();window.print();});
$("saveQuoteBtn").addEventListener("click",saveQuote);
$("newQuoteBtn").addEventListener("click",()=>{
  if(!confirm("بدء عرض جديد؟ تأكد من حفظ العرض الحالي أولًا إذا كنت تحتاجه.")) return;
  setForm({quoteDate:todayISO()}); status("تم فتح عرض جديد.");
});
$("loadQuoteBtn").addEventListener("click",()=>{
  const id=$("savedQuotes").value; const q=readQuotes().find(x=>x.id===id);
  if(!q) return status("اختر عرضًا محفوظًا أولًا.",true);
  setForm(q); status("تم فتح العرض المحفوظ.");
});
$("deleteQuoteBtn").addEventListener("click",()=>{
  const id=$("savedQuotes").value;
  if(!id) return status("اختر عرضًا لحذفه.",true);
  if(!confirm("هل تريد حذف عرض السعر المحفوظ؟")) return;
  writeQuotes(readQuotes().filter(q=>q.id!==id)); refreshSaved(); status("تم حذف العرض.");
});
$("exportBtn").addEventListener("click",()=>downloadJSON({app:"Mojah Quotations",version:1,quotes:readQuotes(),products:readProducts()},"mojah-quotes-backup.json"));
$("importFile").addEventListener("change",async e=>{
  const file=e.target.files[0]; if(!file) return;
  try {
    const data=JSON.parse(await file.text());
    const imported=Array.isArray(data)?data:data.quotes;
    if(!Array.isArray(imported)) throw new Error("invalid");
    if(data.products !== undefined && (!Array.isArray(data.products) || data.products.some(product => typeof product !== "string"))) throw new Error("invalid");
    const current=readQuotes();
    imported.forEach(q=>{if(q&&q.id){const i=current.findIndex(x=>x.id===q.id);if(i>=0)current[i]=q;else current.push(q);}});
    if(writeQuotes(current)){
      if(Array.isArray(data.products)) {
        const products=readProducts();
        data.products.forEach(product=>{
          if(!products.some(saved=>saved.toLocaleLowerCase()===safeText(product).toLocaleLowerCase())) products.push(safeText(product));
        });
        if(!writeProducts(products)) return;
        refreshProductCatalog();
      }
      refreshSaved();status("تم استيراد النسخة الاحتياطية.");
    }
  } catch(err) { status("ملف النسخة الاحتياطية غير صالح.",true); }
  e.target.value="";
});
["quoteNo","quoteDate","customer","subject","discount","terms"].forEach(id=>$(id).addEventListener("input",renderPreview));
$("vatEnabled").addEventListener("change",renderPreview);
setForm({quoteDate:todayISO()});
refreshSaved();
